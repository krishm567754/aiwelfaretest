import Navbar from '@/sections/Navbar'
import Hero from '@/sections/Hero'
import PriceTicker from '@/sections/PriceTicker'
import Roles from '@/sections/Roles'
import PriceBoard from '@/sections/PriceBoard'
import SmartRouting from '@/sections/SmartRouting'
import ModelCoverage from '@/sections/ModelCoverage'
import QuickStart from '@/sections/QuickStart'
import Footer from '@/sections/Footer'

export default function Home() {
  return (
    <div className="min-h-screen bg-[#04070d] text-slate-100">
      <Navbar />
      <main>
        <Hero />
        <PriceTicker />
        <Roles />
        <PriceBoard />
        <SmartRouting />
        <ModelCoverage />
        <QuickStart />
      </main>
      <Footer />
    </div>
  )
}
