import { Logo } from './Navbar'
import { MessageCircle } from 'lucide-react'

const cols = [
  {
    title: '合作',
    links: ['供应商入驻', '代理合作', '渠道经营'],
  },
  {
    title: '产品',
    links: ['模型市场', '接入文档'],
  },
  {
    title: '承诺',
    links: ['全网比价', '最优价格优先', '稳定质量路由'],
  },
]

export default function Footer() {
  return (
    <>
      <footer className="border-t border-white/[0.07] bg-white/[0.015]">
        <div className="mx-auto max-w-7xl px-5 py-14 lg:px-8">
          <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
            <div>
              <Logo />
              <p className="mt-5 max-w-sm text-sm leading-relaxed text-slate-500">
                模型供应商、渠道代理和终端用户的统一交易网络。
                我们负责比价、路由、风控和结算，让低价和稳定变成平台能力。
              </p>
            </div>
            {cols.map((c) => (
              <div key={c.title}>
                <div className="mb-4 text-sm font-bold text-white">{c.title}</div>
                <ul className="space-y-2.5">
                  {c.links.map((l) => (
                    <li key={l}>
                      <a href="#top" className="text-sm text-slate-500 transition-colors hover:text-cyan-300">
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/[0.06] pt-6 sm:flex-row">
            <span className="text-xs text-slate-600">© 2026 A6api.com · 大模型 API 比价路由平台</span>
            <span className="font-mono2 text-[11px] text-slate-600">OpenAI Compatible API · /v1/chat/completions</span>
          </div>
        </div>
      </footer>

      {/* floating contact */}
      <a
        href="#top"
        className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full border border-white/10 bg-[#0a1524]/90 px-4 py-2.5 text-xs font-semibold text-slate-200 shadow-2xl backdrop-blur-xl transition-all hover:border-cyan-400/40 hover:text-cyan-300"
      >
        <MessageCircle className="h-4 w-4 text-cyan-400" />
        联系我们
      </a>
    </>
  )
}
