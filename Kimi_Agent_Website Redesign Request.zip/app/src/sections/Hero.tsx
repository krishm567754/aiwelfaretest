import { useEffect, useState } from 'react'
import { ArrowRight, Zap, GitCompareArrows, BadgePercent, ShieldCheck, RefreshCcw } from 'lucide-react'

const chips = [
  { icon: Zap, label: '统一 API' },
  { icon: GitCompareArrows, label: '全网比价' },
  { icon: BadgePercent, label: '低价优先' },
  { icon: ShieldCheck, label: '稳定输出' },
  { icon: RefreshCcw, label: '自动切换' },
]

const logs = [
  { model: 'gpt-5.6-terra', ms: 212, status: '200' },
  { model: 'claude-opus-4.6', ms: 348, status: '200' },
  { model: 'deepseek-v4', ms: 186, status: '200' },
  { model: 'gpt-5.4', ms: 264, status: '200' },
  { model: 'gemini-3-pro', ms: 301, status: '200' },
]

function RoutingVisual() {
  const [i, setI] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % logs.length), 1800)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="relative mx-auto w-full max-w-[520px]">
      {/* glow backdrop */}
      <div className="absolute inset-0 -z-10 scale-90 rounded-full bg-[radial-gradient(circle_at_50%_45%,rgba(34,211,238,0.16),rgba(52,211,153,0.07)_45%,transparent_70%)] blur-2xl" />

      <svg viewBox="0 0 520 440" className="w-full">
        <defs>
          <linearGradient id="hubGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#22d3ee" />
            <stop offset="55%" stopColor="#0ea5e9" />
            <stop offset="100%" stopColor="#34d399" />
          </linearGradient>
          <linearGradient id="lineGrad" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.05" />
            <stop offset="50%" stopColor="#67e8f9" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#34d399" stopOpacity="0.05" />
          </linearGradient>
        </defs>

        {/* orbit rings */}
        <circle cx="260" cy="205" r="150" fill="none" stroke="rgba(148,197,255,0.10)" strokeDasharray="3 7" />
        <circle cx="260" cy="205" r="108" fill="none" stroke="rgba(148,197,255,0.07)" />

        {/* connection paths */}
        <path id="p-supplier" d="M 96 96 C 150 120, 190 150, 224 178" fill="none" stroke="url(#lineGrad)" strokeWidth="1.5" className="animate-dash" />
        <path id="p-partner" d="M 424 96 C 370 120, 330 150, 296 178" fill="none" stroke="url(#lineGrad)" strokeWidth="1.5" className="animate-dash" />
        <path id="p-user" d="M 260 372 C 260 330, 260 300, 260 262" fill="none" stroke="url(#lineGrad)" strokeWidth="1.5" className="animate-dash" />

        {/* moving packets */}
        <circle r="3.5" fill="#67e8f9">
          <animateMotion dur="2.6s" repeatCount="indefinite"><mpath href="#p-supplier" /></animateMotion>
        </circle>
        <circle r="3.5" fill="#34d399">
          <animateMotion dur="3.1s" repeatCount="indefinite" begin="0.7s"><mpath href="#p-partner" /></animateMotion>
        </circle>
        <circle r="3.5" fill="#38bdf8">
          <animateMotion dur="2.2s" repeatCount="indefinite" begin="0.3s"><mpath href="#p-user" /></animateMotion>
        </circle>
      </svg>

      {/* satellite nodes */}
      <div className="animate-float absolute left-[6%] top-[14%] flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1.5">
        <div className="glass grid h-14 w-14 place-items-center rounded-2xl text-sm font-bold text-cyan-300">供</div>
        <span className="text-xs text-slate-400">供应商</span>
      </div>
      <div className="animate-float-slow absolute left-[94%] top-[14%] flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1.5">
        <div className="glass grid h-14 w-14 place-items-center rounded-2xl text-sm font-bold text-emerald-300">代</div>
        <span className="text-xs text-slate-400">伙伴</span>
      </div>
      <div className="animate-float absolute bottom-[2%] left-1/2 flex -translate-x-1/2 flex-col items-center gap-1.5" style={{ animationDelay: '1.4s' }}>
        <div className="glass grid h-14 w-14 place-items-center rounded-2xl text-sm font-bold text-sky-300">用</div>
        <span className="text-xs text-slate-400">用户</span>
      </div>

      {/* central hub */}
      <div className="absolute left-1/2 top-[46.5%] -translate-x-1/2 -translate-y-1/2">
        <div className="glow-cyan relative grid h-36 w-36 place-items-center rounded-full bg-gradient-to-br from-cyan-400 via-sky-500 to-emerald-400 text-slate-950">
          <div className="animate-spin-slower absolute inset-0 rounded-full border border-dashed border-white/40" style={{ margin: '-9px' }} />
          <div className="text-center">
            <div className="font-mono2 text-[10px] font-semibold uppercase tracking-widest opacity-70">A6api</div>
            <div className="text-lg font-black leading-tight">比价路由</div>
            <div className="mt-0.5 text-[10px] font-medium opacity-80">质量优选 · 自动分发</div>
          </div>
        </div>
      </div>

      {/* live request log */}
      <div className="glass-deep absolute -bottom-2 left-1/2 w-[300px] -translate-x-1/2 overflow-hidden rounded-xl shadow-2xl sm:left-auto sm:right-0 sm:translate-x-0">
        <div className="flex items-center justify-between border-b border-white/[0.07] px-3.5 py-2">
          <span className="flex items-center gap-1.5 text-[11px] text-slate-400">
            <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
            实时请求
          </span>
          <span className="font-mono2 text-[10px] text-slate-600">/v1/chat/completions</span>
        </div>
        <div className="relative h-[74px] px-3.5 py-2">
          <div className="animate-scan absolute inset-x-0 top-0 h-6 bg-gradient-to-b from-transparent via-cyan-400/[0.07] to-transparent" />
          {[0, 1, 2].map((k) => {
            const log = logs[(i + k) % logs.length]
            return (
              <div key={`${log.model}-${(i + k) % logs.length}`} className="flex items-center justify-between py-[3px] font-mono2 text-[11px] transition-opacity" style={{ opacity: 1 - k * 0.32 }}>
                <span className="text-slate-300">{log.model}</span>
                <span className="flex items-center gap-2">
                  <span className="text-slate-500">{log.ms}ms</span>
                  <span className="text-emerald-400">{log.status}</span>
                </span>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}

export default function Hero() {
  return (
    <section id="top" className="relative overflow-hidden pb-24 pt-32 lg:pt-40">
      <div className="grid-bg absolute inset-0 -z-10" />
      <div className="absolute -top-32 left-1/2 -z-10 h-[480px] w-[820px] -translate-x-1/2 rounded-full bg-[radial-gradient(ellipse_at_center,rgba(14,116,144,0.25),transparent_65%)] blur-3xl" />

      <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 lg:grid-cols-2 lg:gap-8 lg:px-8">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyan-400/25 bg-cyan-400/[0.07] px-3.5 py-1.5 text-xs font-medium text-cyan-300">
            <span className="animate-pulse-dot h-1.5 w-1.5 rounded-full bg-emerald-400" />
            全网比价 · 智能路由 · 自动分发
          </div>

          <h1 className="text-4xl font-black leading-[1.15] tracking-tight text-white sm:text-5xl lg:text-[3.4rem]">
            招募全网优质商家
            <br />
            <span className="text-gradient">共建极速便捷生态</span>
          </h1>

          <p className="mt-6 max-w-xl text-base leading-relaxed text-slate-400 sm:text-lg">
            一个连接模型供应商、合作伙伴和个人用户的模型市场。系统自动比较多家渠道，
            在价格、成功率和延迟之间选择更合适的线路。
          </p>

          <div className="mt-9 flex flex-wrap items-center gap-3.5">
            <a
              href="#roles"
              className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-6 py-3 text-sm font-bold text-slate-950 transition-all hover:shadow-[0_0_36px_-6px_rgba(34,211,238,0.75)]"
            >
              供应商合作
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#roles"
              className="rounded-xl border border-white/15 bg-white/[0.04] px-6 py-3 text-sm font-semibold text-slate-200 transition-colors hover:border-cyan-400/40 hover:text-white"
            >
              伙伴计划
            </a>
            <a href="#quickstart" className="group inline-flex items-center gap-1.5 px-2 py-3 text-sm font-medium text-cyan-300 hover:text-cyan-200">
              立即使用
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </div>

          <div className="mt-10 flex flex-wrap gap-2.5">
            {chips.map((c) => (
              <span
                key={c.label}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/[0.09] bg-white/[0.03] px-3.5 py-1.5 text-xs text-slate-300 transition-colors hover:border-cyan-400/30 hover:text-cyan-200"
              >
                <c.icon className="h-3.5 w-3.5 text-cyan-400" />
                {c.label}
              </span>
            ))}
          </div>
        </div>

        <RoutingVisual />
      </div>
    </section>
  )
}
