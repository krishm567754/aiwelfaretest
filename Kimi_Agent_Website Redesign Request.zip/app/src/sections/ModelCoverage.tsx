import { MessageSquare, Code2, FileText, Layers, Image } from 'lucide-react'
import Reveal from '@/components/Reveal'

const brands = [
  { name: 'OpenAI', mark: 'OA', hue: 'from-emerald-400/20 to-emerald-400/5 text-emerald-300' },
  { name: 'Claude', mark: 'C', hue: 'from-orange-400/20 to-orange-400/5 text-orange-300' },
  { name: 'Gemini', mark: 'G', hue: 'from-sky-400/20 to-sky-400/5 text-sky-300' },
  { name: 'DeepSeek', mark: 'DS', hue: 'from-indigo-400/20 to-indigo-400/5 text-indigo-300' },
  { name: 'GLM', mark: 'GLM', hue: 'from-violet-400/20 to-violet-400/5 text-violet-300' },
  { name: '图片模型', mark: 'Im', hue: 'from-pink-400/20 to-pink-400/5 text-pink-300' },
]

const caps = [
  { icon: MessageSquare, label: '对话' },
  { icon: Code2, label: '编程' },
  { icon: FileText, label: '长文本' },
  { icon: Layers, label: '多模态' },
  { icon: Image, label: '图片生成' },
]

export default function ModelCoverage() {
  return (
    <section className="relative py-24">
      <div className="absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent" />
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal>
          <div className="mx-auto mb-14 max-w-2xl text-center">
            <span className="font-mono2 text-xs font-semibold uppercase tracking-[0.25em] text-sky-400">模型覆盖</span>
            <h2 className="mt-3 text-3xl font-black tracking-tight text-white sm:text-4xl">
              别再到处找模型了，
              <span className="text-gradient">一个入口先用起来</span>
            </h2>
            <p className="mt-4 leading-relaxed text-slate-400">
              覆盖 OpenAI、Claude、Gemini、DeepSeek、GLM、图片模型等常用方向。
              开发者和团队可以用统一 API 管理模型调用，少维护多个供应商账号。
            </p>
          </div>
        </Reveal>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {brands.map((b, i) => (
            <Reveal key={b.name} delay={i * 80}>
              <div className="group flex h-full flex-col items-center gap-3 rounded-2xl border border-white/[0.08] bg-white/[0.025] px-4 py-7 transition-all duration-300 hover:-translate-y-1 hover:border-white/20 hover:bg-white/[0.05]">
                <span className={`grid h-12 w-12 place-items-center rounded-xl bg-gradient-to-br font-mono2 text-sm font-bold ${b.hue}`}>
                  {b.mark}
                </span>
                <span className="text-sm font-semibold text-slate-200">{b.name}</span>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div className="mt-10 flex flex-wrap justify-center gap-2.5">
            {caps.map((c) => (
              <span
                key={c.label}
                className="inline-flex items-center gap-1.5 rounded-full border border-white/[0.09] bg-white/[0.03] px-4 py-2 text-xs text-slate-300 transition-colors hover:border-sky-400/30 hover:text-sky-200"
              >
                <c.icon className="h-3.5 w-3.5 text-sky-400" />
                {c.label}
              </span>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  )
}
