import { useEffect, useState } from 'react'
import { Menu, X, ArrowUpRight } from 'lucide-react'
import { cn } from '@/lib/utils'

const links = [
  { label: '首页', href: '#top' },
  { label: '模型市场', href: '#prices' },
  { label: '文档', href: '#quickstart' },
  { label: '控制台', href: '#quickstart' },
  { label: '商家入驻', href: '#roles' },
]

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#top" className="group flex items-center gap-2.5">
      <span className="relative grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-cyan-400 via-sky-500 to-emerald-400 font-mono2 text-sm font-bold text-slate-950 shadow-[0_0_24px_-6px_rgba(34,211,238,0.7)] transition-transform duration-300 group-hover:scale-105">
        A6
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className="block text-[15px] font-bold tracking-wide text-white">A6api</span>
          <span className="block font-mono2 text-[10px] tracking-wider text-slate-500">a6api.com</span>
        </span>
      )}
    </a>
  )
}

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-all duration-300',
        scrolled ? 'border-b border-white/[0.07] bg-[#04070d]/85 backdrop-blur-xl' : 'bg-transparent'
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 lg:px-8">
        <Logo />

        <nav className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="rounded-lg px-3.5 py-2 text-sm text-slate-400 transition-colors hover:bg-white/[0.06] hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2.5 lg:flex">
          <a
            href="#quickstart"
            className="rounded-lg px-4 py-2 text-sm font-medium text-slate-300 transition-colors hover:text-white"
          >
            登录
          </a>
          <a
            href="#quickstart"
            className="group inline-flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-cyan-400 to-emerald-400 px-4 py-2 text-sm font-semibold text-slate-950 transition-all hover:shadow-[0_0_28px_-6px_rgba(52,211,153,0.8)]"
          >
            注册
            <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        <button
          className="grid h-10 w-10 place-items-center rounded-lg text-slate-300 hover:bg-white/[0.06] lg:hidden"
          onClick={() => setOpen(!open)}
          aria-label="菜单"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-white/[0.07] bg-[#04070d]/95 px-5 py-4 backdrop-blur-xl lg:hidden">
          <nav className="flex flex-col gap-1">
            {links.map((l) => (
              <a
                key={l.label}
                href={l.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm text-slate-300 hover:bg-white/[0.06] hover:text-white"
              >
                {l.label}
              </a>
            ))}
            <div className="mt-3 flex gap-2.5">
              <a href="#quickstart" className="flex-1 rounded-lg border border-white/10 px-4 py-2.5 text-center text-sm text-slate-200">
                登录
              </a>
              <a
                href="#quickstart"
                className="flex-1 rounded-lg bg-gradient-to-r from-cyan-400 to-emerald-400 px-4 py-2.5 text-center text-sm font-semibold text-slate-950"
              >
                注册
              </a>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
