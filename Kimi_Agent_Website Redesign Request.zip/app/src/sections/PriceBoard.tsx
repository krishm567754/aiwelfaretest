import { ArrowRight, TrendingDown, Wallet, Store, MousePointerClick } from 'lucide-react'
import Reveal from '@/components/Reveal'

const deals = [
  { model: 'gpt-5.6-terra', vendor: 'OpenAI', price: '$0.009000', spark: [22, 20, 21, 17, 15, 16, 12, 10], hot: true },
  { model: 'gpt-5.4', vendor: 'OpenAI', price: '$0.009000', spark: [18, 19, 16, 15, 14, 12, 12, 11], hot: false },
  { model: 'claude-opus-4.6', vendor: 'Anthropic', price: '$0.0120', spark: [24, 22, 20, 19, 17, 16, 15, 14], hot: false },
  { model: 'gpt-5.6-sol', vendor: 'OpenAI', price: '$0.0144', spark: [26, 24, 23, 21, 20, 19, 18, 17], hot: false },
]

const perks = [
  { icon: Store, title: '多商家供货', desc: '同一模型多家商家供货，价格被真实竞争卷下来。' },
  { icon: TrendingDown, title: '低价入口可见', desc: '不用自己到处比价，先从更有竞争力的低价模型开始。' },
  { icon: Wallet, title: '按量使用', desc: '不用先买大套餐，低额充值起，先试一次再决定。' },
]

function Spark({ points }: { points: number[] }) {
  const max = Math.max(...points)
  const min = Math.min(...points)
  const w = 96
  const h = 30
  const step = w / (points.length - 1)
  const d = points
    .map((p, i) => `${i === 0 ? 'M' : 'L'} ${(i * step).toFixed(1)} ${(h - 4 - ((p - min) / (max - min || 1)) * (h - 8)).toFixed(1)}`)
    .join(' ')
  return (
    <svg width={w} height={h} className="opacity-80">
      <path d={d} fill="none" stroke="#34d399" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx={w} cy={h - 4 - ((points[points.length - 1] - min) / (max - min || 1)) * (h - 8)} r="2.4" fill="#34d399" />
    </svg>
  )
}

export default function PriceBoard() {
  return (
    <section id="prices" className="relative py-24">
      <div className="absolute inset-x-0 top-1/3 -z-10 h-[420px] bg-[radial-gradient(ellipse_at_center,rgba(52,211,153,0.07),transparent_65%)] blur-3xl" />
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-[1fr_1.25fr] lg:items-center">
          {/* left copy */}
          <Reveal>
            <div>
              <span className="font-mono2 text-xs font-semibold uppercase tracking-[0.25em] text-emerald-400">低价橱窗 · 实时低价榜</span>
              <h2 className="mt-3 text-3xl font-black leading-tight tracking-tight text-white sm:text-[2.6rem]">
                低到不试一下，
                <br />
                <span className="text-gradient">都有点可惜</span>
              </h2>
              <p className="mt-5 leading-relaxed text-slate-400">
                多商家供货形成价格竞争，首页只放少量低价入口做参考。完整价格、输出价和更多供应商，以模型市场为准。
              </p>

              <div className="mt-8 space-y-5">
                {perks.map((p) => (
                  <div key={p.title} className="flex gap-4">
                    <span className="mt-0.5 grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-emerald-400/20 bg-emerald-400/[0.08] text-emerald-300">
                      <p.icon className="h-4 w-4" />
                    </span>
                    <div>
                      <div className="font-semibold text-white">{p.title}</div>
                      <div className="mt-1 text-sm text-slate-400">{p.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* right board */}
          <Reveal delay={150}>
            <div className="glass-deep relative overflow-hidden rounded-2xl p-6 shadow-2xl sm:p-7">
              <div className="absolute -right-20 -top-20 h-56 w-56 rounded-full bg-emerald-400/10 blur-3xl" />
              <div className="mb-5 flex items-center justify-between">
                <span className="flex items-center gap-2 text-sm font-semibold text-white">
                  <span className="animate-pulse-dot h-2 w-2 rounded-full bg-emerald-400" />
                  今日低价入口
                </span>
                <span className="flex items-center gap-1.5 text-xs text-slate-500">
                  <MousePointerClick className="h-3.5 w-3.5" />
                  点击卡片进入模型市场
                </span>
              </div>

              <div className="grid gap-3.5 sm:grid-cols-2">
                {deals.map((d) => (
                  <a
                    key={d.model}
                    href="#prices"
                    className="group relative overflow-hidden rounded-xl border border-white/[0.08] bg-white/[0.03] p-4 transition-all duration-300 hover:-translate-y-1 hover:border-emerald-400/35 hover:bg-white/[0.05]"
                  >
                    {d.hot && (
                      <span className="absolute right-3 top-3 rounded-full bg-emerald-400/15 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                        全网最低
                      </span>
                    )}
                    <div className="flex items-center gap-2">
                      <span className="font-mono2 text-sm font-semibold text-slate-100">{d.model}</span>
                    </div>
                    <span className="mt-1.5 inline-block rounded border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-500">
                      {d.vendor}
                    </span>
                    <div className="mt-3 flex items-end justify-between">
                      <div>
                        <span className="font-mono2 text-xl font-bold text-emerald-400">{d.price}</span>
                        <span className="ml-1 text-[11px] text-slate-500">/ 1M tokens</span>
                      </div>
                      <Spark points={d.spark} />
                    </div>
                  </a>
                ))}
              </div>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.07] pt-5">
                <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3.5 py-1.5 text-xs text-slate-300">
                  <Wallet className="h-3.5 w-3.5 text-emerald-400" />
                  低额充值起 · 先跑通一次真实调用再决定
                </span>
                <a
                  href="#prices"
                  className="group inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-300 hover:text-emerald-200"
                >
                  查看完整模型价格
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
