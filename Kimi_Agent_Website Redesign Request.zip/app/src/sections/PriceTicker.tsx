const items = [
  { model: 'gpt-5.6-terra', vendor: 'OpenAI', price: '$0.0090' },
  { model: 'gpt-5.4', vendor: 'OpenAI', price: '$0.0090' },
  { model: 'claude-opus-4.6', vendor: 'Anthropic', price: '$0.0120' },
  { model: 'gpt-5.6-sol', vendor: 'OpenAI', price: '$0.0144' },
  { model: 'deepseek-v4', vendor: 'DeepSeek', price: '$0.0027' },
  { model: 'gemini-3-pro', vendor: 'Google', price: '$0.0108' },
  { model: 'glm-5', vendor: '智谱', price: '$0.0036' },
  { model: 'qwen-max', vendor: '阿里', price: '$0.0042' },
]

export default function PriceTicker() {
  const doubled = [...items, ...items]
  return (
    <div className="relative border-y border-white/[0.06] bg-white/[0.015] py-3.5">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#04070d] to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#04070d] to-transparent" />
      <div className="overflow-hidden">
        <div className="animate-marquee flex w-max items-center gap-10 px-5">
          {doubled.map((it, idx) => (
            <span key={idx} className="flex items-center gap-2.5 whitespace-nowrap font-mono2 text-xs">
              <span className="text-slate-300">{it.model}</span>
              <span className="rounded border border-white/10 px-1.5 py-0.5 text-[10px] text-slate-500">{it.vendor}</span>
              <span className="font-semibold text-emerald-400">{it.price}</span>
              <span className="text-slate-600">/1M</span>
              <span className="ml-4 h-1 w-1 rounded-full bg-slate-700" />
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
