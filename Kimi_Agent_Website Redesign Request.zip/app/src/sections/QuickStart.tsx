import { useState } from 'react'
import { Check, Copy, UserPlus, KeyRound, Play, ArrowRight } from 'lucide-react'
import Reveal from '@/components/Reveal'

const steps = [
  { icon: UserPlus, title: '完成注册 / 登录', desc: '一个账号，通行模型市场与控制台' },
  { icon: KeyRound, title: '创建 API Key', desc: '一键生成，按量计费，随时吊销' },
  { icon: Play, title: '跑通第一次真实调用', desc: '去 Playground 验证价格、延迟与稳定性' },
]

const code = `curl https://api.a6api.com/v1/chat/completions \\
  -H "Authorization: Bearer $A6_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "model": "gpt-5.4",
    "messages": [{ "role": "user", "content": "你好" }]
  }'`

export default function QuickStart() {
  const [copied, setCopied] = useState(false)

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1600)
    } catch {
      setCopied(false)
    }
  }

  return (
    <section id="quickstart" className="relative py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal>
          <div className="glass relative overflow-hidden rounded-3xl p-8 sm:p-12">
            <div className="grid-bg absolute inset-0 opacity-60" />
            <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan-400/10 blur-3xl" />
            <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-emerald-400/10 blur-3xl" />

            <div className="relative grid gap-12 lg:grid-cols-2 lg:items-center">
              <div>
                <span className="font-mono2 text-xs font-semibold uppercase tracking-[0.25em] text-cyan-400">快速开始</span>
                <h2 className="mt-3 text-3xl font-black leading-tight tracking-tight text-white sm:text-4xl">
                  几分钟内
                  <br />
                  跑通第一次调用
                </h2>
                <p className="mt-4 leading-relaxed text-slate-400">
                  低额充值起也能体验真实调用。先用一次，确认真的便宜、线路也省心，再决定是否长期使用。
                </p>

                <div className="mt-8 space-y-4">
                  {steps.map((s, i) => (
                    <div key={s.title} className="flex items-center gap-4">
                      <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[0.05] font-mono2 text-sm font-bold text-cyan-300">
                        {i + 1}
                      </span>
                      <div>
                        <div className="text-sm font-bold text-white">{s.title}</div>
                        <div className="text-xs text-slate-500">{s.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <a
                  href="#top"
                  className="group mt-9 inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-400 to-emerald-400 px-6 py-3 text-sm font-bold text-slate-950 transition-all hover:shadow-[0_0_36px_-6px_rgba(52,211,153,0.75)]"
                >
                  注册开始使用
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </div>

              {/* code block */}
              <div className="overflow-hidden rounded-2xl border border-white/[0.09] bg-[#060c16] shadow-2xl">
                <div className="flex items-center justify-between border-b border-white/[0.07] px-4 py-2.5">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-red-400/70" />
                    <span className="h-2.5 w-2.5 rounded-full bg-amber-400/70" />
                    <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
                  </div>
                  <span className="font-mono2 text-[11px] text-slate-500">第一次调用</span>
                  <button
                    onClick={copy}
                    className="flex items-center gap-1 rounded-md px-2 py-1 text-[11px] text-slate-400 transition-colors hover:bg-white/[0.06] hover:text-white"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? '已复制' : '复制'}
                  </button>
                </div>
                <pre className="overflow-x-auto p-5 font-mono2 text-[12.5px] leading-relaxed">
                  <code>
                    <span className="text-cyan-300">curl</span>
                    <span className="text-slate-300"> https://api.a6api.com/v1/chat/completions \</span>
                    {'\n'}
                    <span className="text-slate-300">  -H </span>
                    <span className="text-emerald-300">"Authorization: Bearer $A6_API_KEY"</span>
                    <span className="text-slate-300"> \</span>
                    {'\n'}
                    <span className="text-slate-300">  -H </span>
                    <span className="text-emerald-300">"Content-Type: application/json"</span>
                    <span className="text-slate-300"> \</span>
                    {'\n'}
                    <span className="text-slate-300">  -d </span>
                    <span className="text-amber-200">'{'{'}</span>
                    {'\n'}
                    <span className="text-amber-200">    "model": "gpt-5.4",</span>
                    {'\n'}
                    <span className="text-amber-200">    "messages": [{'{'} "role": "user", "content": "你好" {'}'}]</span>
                    {'\n'}
                    <span className="text-amber-200">  {'}'}'</span>
                  </code>
                </pre>
                <div className="border-t border-white/[0.07] bg-emerald-400/[0.05] px-5 py-3 font-mono2 text-[11px] text-emerald-300/80">
                  → 200 OK · 已为你路由至当前最低价的可用渠道
                </div>
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
