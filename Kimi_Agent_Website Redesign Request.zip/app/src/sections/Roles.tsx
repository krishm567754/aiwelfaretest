import { Store, Network, KeyRound, ArrowUpRight } from 'lucide-react'
import Reveal from '@/components/Reveal'

const roles = [
  {
    icon: Store,
    tag: '供',
    accent: 'text-cyan-300',
    accentBg: 'from-cyan-400/15 to-transparent',
    ring: 'group-hover:border-cyan-400/40',
    title: '模型供应商入驻',
    desc: '如果您拥有稳定、合规的模型渠道，欢迎接入平台。我们将为您精准导入持续、真实的 API 调用请求。',
    cta: '洽谈供给合作',
  },
  {
    icon: Network,
    tag: '代',
    accent: 'text-emerald-300',
    accentBg: 'from-emerald-400/15 to-transparent',
    ring: 'group-hover:border-emerald-400/40',
    title: '推广与生态伙伴',
    desc: '面向开发者、企业或社群提供增值服务。一键封装平台的底层路由能力，快速满足您客户群体的 AI 需求。',
    cta: '加入伙伴计划',
  },
  {
    icon: KeyRound,
    tag: '用',
    accent: 'text-sky-300',
    accentBg: 'from-sky-400/15 to-transparent',
    ring: 'group-hover:border-sky-400/40',
    title: '个人 / 企业直接调用',
    desc: '零门槛接入。一键创建 API Key，以极具竞争力的价格，稳定调用全球主流大模型。',
    cta: '立即生成 API Key',
  },
]

export default function Roles() {
  return (
    <section id="roles" className="relative py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <Reveal>
          <div className="mb-14 max-w-2xl">
            <span className="font-mono2 text-xs font-semibold uppercase tracking-[0.25em] text-cyan-400">三方共赢</span>
            <h2 className="mt-3 text-3xl font-black tracking-tight text-white sm:text-4xl">
              一个市场，三种角色
            </h2>
            <p className="mt-4 text-slate-400">
              平台负责比价、路由、风控和结算。供应商获得真实流量，伙伴获得封装能力，用户获得底价与稳定。
            </p>
          </div>
        </Reveal>

        <div className="grid gap-5 md:grid-cols-3">
          {roles.map((r, i) => (
            <Reveal key={r.title} delay={i * 120}>
              <a
                href="#quickstart"
                className={`group relative flex h-full flex-col overflow-hidden rounded-2xl border border-white/[0.08] bg-white/[0.025] p-7 transition-all duration-300 hover:-translate-y-1.5 hover:bg-white/[0.045] ${r.ring}`}
              >
                <div className={`absolute inset-x-0 top-0 h-28 bg-gradient-to-b ${r.accentBg} opacity-0 transition-opacity duration-300 group-hover:opacity-100`} />
                <div className="relative">
                  <div className="mb-6 flex items-center justify-between">
                    <span className={`grid h-12 w-12 place-items-center rounded-xl border border-white/10 bg-white/[0.04] ${r.accent}`}>
                      <r.icon className="h-5 w-5" />
                    </span>
                    <span className={`font-mono2 text-xs ${r.accent} opacity-60`}>0{i + 1}</span>
                  </div>
                  <h3 className="text-lg font-bold text-white">{r.title}</h3>
                  <p className="mt-3 flex-1 text-sm leading-relaxed text-slate-400">{r.desc}</p>
                  <span className={`mt-6 inline-flex items-center gap-1.5 text-sm font-semibold ${r.accent}`}>
                    {r.cta}
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </span>
                </div>
              </a>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
