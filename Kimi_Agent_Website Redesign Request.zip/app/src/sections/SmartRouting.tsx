import { useEffect, useState } from 'react'
import { Route, Scale, BrainCircuit, ArrowDown } from 'lucide-react'
import Reveal from '@/components/Reveal'
import { cn } from '@/lib/utils'

const features = [
  {
    icon: Route,
    title: '渠道波动',
    desc: '遇到部分线路异常、限流或不可用时，自动切换到其他可用线路。',
  },
  {
    icon: Scale,
    title: '价格与稳定',
    desc: '在价格、成功率和延迟之间做平衡，减少手动换 Key 的麻烦。',
  },
  {
    icon: BrainCircuit,
    title: '大请求学习',
    desc: '遇到不适合的大请求线路，后续自动绕开，降低反复失败概率。',
  },
]

const channels = [
  { name: '渠道 · 华东-A', latency: 186, success: 99.8, price: '$0.0090', status: 'active' },
  { name: '渠道 · 华北-B', latency: 243, success: 99.5, price: '$0.0092', status: 'standby' },
  { name: '渠道 · 华南-C', latency: 0, success: 0, price: '$0.0088', status: 'limited' },
  { name: '渠道 · 香港-D', latency: 312, success: 98.9, price: '$0.0104', status: 'standby' },
] as const

function RouterPanel() {
  const [tick, setTick] = useState(0)
  useEffect(() => {
    const t = setInterval(() => setTick((v) => v + 1), 2600)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="glass-deep relative overflow-hidden rounded-2xl p-6 shadow-2xl sm:p-7">
      <div className="absolute -left-16 -top-16 h-48 w-48 rounded-full bg-cyan-400/10 blur-3xl" />

      {/* flow header: 请求 → 优选 → 渠道 */}
      <div className="relative mb-6 flex items-center gap-3">
        <div className="flex-1 rounded-xl border border-white/[0.09] bg-white/[0.04] px-4 py-3 text-center">
          <div className="text-[11px] text-slate-500">STEP 1</div>
          <div className="text-sm font-bold text-white">请求进入</div>
        </div>
        <ArrowDown className="h-4 w-4 -rotate-90 text-cyan-400" />
        <div className="flex-1 rounded-xl border border-cyan-400/30 bg-cyan-400/[0.08] px-4 py-3 text-center glow-cyan">
          <div className="text-[11px] text-cyan-400/70">STEP 2</div>
          <div className="text-sm font-bold text-cyan-300">智能优选</div>
        </div>
        <ArrowDown className="h-4 w-4 -rotate-90 text-cyan-400" />
        <div className="flex-1 rounded-xl border border-white/[0.09] bg-white/[0.04] px-4 py-3 text-center">
          <div className="text-[11px] text-slate-500">STEP 3</div>
          <div className="text-sm font-bold text-white">可用渠道</div>
        </div>
      </div>

      {/* channel list */}
      <div className="relative space-y-2.5">
        {channels.map((c) => {
          const isActive = c.status === 'active'
          const isLimited = c.status === 'limited'
          return (
            <div
              key={c.name}
              className={cn(
                'flex items-center justify-between rounded-xl border px-4 py-3 transition-all duration-500',
                isActive && 'border-emerald-400/35 bg-emerald-400/[0.07]',
                c.status === 'standby' && 'border-white/[0.07] bg-white/[0.02]',
                isLimited && 'border-red-400/20 bg-red-400/[0.04] opacity-70'
              )}
            >
              <div className="flex items-center gap-3">
                <span
                  className={cn(
                    'h-2 w-2 rounded-full',
                    isActive && 'animate-pulse-dot bg-emerald-400',
                    c.status === 'standby' && 'bg-slate-600',
                    isLimited && 'bg-red-400'
                  )}
                />
                <span className="text-sm text-slate-200">{c.name}</span>
              </div>
              <div className="flex items-center gap-4 font-mono2 text-[11px]">
                {isLimited ? (
                  <span className="rounded bg-red-400/15 px-2 py-0.5 font-sans text-[10px] font-semibold text-red-300">
                    限流 · 已绕行
                  </span>
                ) : (
                  <>
                    <span className="text-slate-500">{c.latency + (isActive ? (tick % 3) * 4 : 0)}ms</span>
                    <span className="hidden text-slate-500 sm:inline">{c.success.toFixed(1)}%</span>
                    <span className="text-emerald-400">{c.price}</span>
                    {isActive && (
                      <span className="rounded bg-emerald-400/15 px-2 py-0.5 font-sans text-[10px] font-semibold text-emerald-300">
                        当前路由
                      </span>
                    )}
                  </>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <p className="relative mt-5 text-xs leading-relaxed text-slate-500">
        你按 OpenAI 兼容方式调用即可。系统会优先尝试更合适的线路，遇到异常、限流或不可用时自动切换。
      </p>
    </div>
  )
}

export default function SmartRouting() {
  return (
    <section className="relative py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center">
          <Reveal>
            <div>
              <span className="font-mono2 text-xs font-semibold uppercase tracking-[0.25em] text-cyan-400">智能优选</span>
              <h2 className="mt-3 text-3xl font-black leading-tight tracking-tight text-white sm:text-4xl">
                不用自己换 Key，
                <br />
                <span className="text-gradient">系统替你找更合适的路</span>
              </h2>

              <div className="mt-9 space-y-6">
                {features.map((f) => (
                  <div key={f.title} className="group flex gap-4">
                    <span className="mt-0.5 grid h-11 w-11 shrink-0 place-items-center rounded-xl border border-cyan-400/20 bg-cyan-400/[0.07] text-cyan-300 transition-colors group-hover:bg-cyan-400/[0.14]">
                      <f.icon className="h-5 w-5" />
                    </span>
                    <div>
                      <div className="font-bold text-white">{f.title}</div>
                      <div className="mt-1 text-sm leading-relaxed text-slate-400">{f.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          <Reveal delay={150}>
            <RouterPanel />
          </Reveal>
        </div>
      </div>
    </section>
  )
}
